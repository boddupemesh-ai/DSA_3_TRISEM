/* GeneScan backend — Express server with page routes.
   Each nav item is a real URL; the SPA router shows the matching page. */

const path = require('path');
const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

// static assets (js/, css-free index, etc.)
app.use('/js', express.static(path.join(ROOT, 'js')));
app.use(express.static(ROOT));

// page routes — same index.html; client router picks the section
const pages = ['', 'pipeline', 'lab', 'performance', 'tech', 'flow'];
pages.forEach(function (p) {
  const route = p === '' ? '/' : '/' + p;
  app.get(route, function (req, res) {
    res.sendFile(path.join(ROOT, 'index.html'));
  });
});

// health check for demo
app.get('/api/health', function (req, res) {
  res.json({
    ok: true,
    app: 'GeneScan',
    algorithms: [
      'suffix-array + Kasai LCP',
      'Smith-Waterman (local)',
      'Needleman-Wunsch (global)',
      'Edmonds-Karp (max-flow)'
    ]
  });
});

app.listen(PORT, function () {
  console.log('GeneScan backend running at http://localhost:' + PORT);
  console.log('  /              Home');
  console.log('  /pipeline      Pipeline');
  console.log('  /lab           Lab');
  console.log('  /performance   Performance');
  console.log('  /tech          Tech & data');
  console.log('  /flow          Network Flow');
});
