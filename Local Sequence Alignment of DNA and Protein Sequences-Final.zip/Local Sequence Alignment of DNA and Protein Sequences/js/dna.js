/* Hero DNA double helix — canvas 3D, no dependencies.
 *
 * The rungs spell the first 27 bases of the human HBB gene (the same codons
 * shown in the hero panel). Base pair 19 is the sickle-cell site: it slowly
 * flips A→T and lights up crimson, then flips back.
 *
 * Interaction: drag to spin (with inertia), move the pointer to tilt,
 * hover a rung to read its base pair. Respects prefers-reduced-motion.
 */
(function () {
  'use strict';

  var canvas = document.getElementById('dnaCanvas');
  if (!canvas || !canvas.getContext) return;
  var ctx = canvas.getContext('2d');
  var reduceMq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };

  /* ---------- data ---------- */
  var SEQ = 'ATGGTGCACCTGACTCCTGAGGAGAAG'; // HBB codons 1–9
  var N = SEQ.length;
  var MUT = 19;                            // the A of GAG (c.20A>T)
  var COMP = { A: 'T', T: 'A', G: 'C', C: 'G' };
  var BASE_RGB = { A: [13, 159, 122], T: [226, 150, 30], G: [63, 99, 217], C: [154, 91, 209] };
  var CRIMSON = [196, 74, 56];
  var STRAND_RGB = [[27, 39, 35], [72, 112, 100]];
  var WHITE = [255, 255, 255];
  var TWIST = (Math.PI * 2) / 10;          // B-DNA: 10 base pairs per turn
  var SUB = 5;                             // backbone samples per rung
  var PAD = 1.5;                           // extra rungs of backbone at each end
  var SPAN = N - 1 + PAD * 2;              // total helix length in rungs
  var MONO = "'IBM Plex Mono', 'SFMono-Regular', Consolas, monospace";

  /* ---------- state ---------- */
  var w = 0, h = 0, dpr = 1;
  var phase = 0.6, vel = 0, pitch = 0.12, roll = -0.36;
  var mx = 0.5, my = 0.5, px = -1, py = -1, inside = false;
  var dragging = false, lastX = 0, lastT = 0;
  var clock = 0, hover = -1;
  var running = false, visible = false, raf = 0, lastFrame = 0;
  var BASE_SPEED = 0.55;
  var motes = [];

  for (var q = 0; q < 26; q++) {
    motes.push({
      x: Math.random(), y: Math.random(),
      size: 10 + Math.random() * 9,
      speed: 0.006 + Math.random() * 0.016,
      ch: 'ATGC'.charAt((Math.random() * 4) | 0),
      a: 0.08 + Math.random() * 0.14
    });
  }

  /* ---------- helpers ---------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function smooth(t) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); }
  function mix(a, b, t) {
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  }
  function css(c) { return 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')'; }
  // Fade toward the page's white instead of using alpha, so overlapping parts stay clean.
  function tint(c, vis) { return css(mix(WHITE, c, clamp(vis, 0, 1))); }

  // 0 = healthy allele, 1 = sickle allele. Holds each state, ramps between.
  function mutAmount(t) {
    var c = t % 10;
    if (c < 3.2) return 0;
    if (c < 4.1) return smooth((c - 3.2) / 0.9);
    if (c < 8.4) return 1;
    if (c < 9.3) return 1 - smooth((c - 8.4) / 0.9);
    return 0;
  }

  function baseAt(i, m) {
    var a = SEQ.charAt(i), b = COMP[a];
    if (i === MUT && m > 0.5) { a = 'T'; b = 'A'; }
    return [a, b];
  }
  function baseColor(letter, i, m) {
    var c = BASE_RGB[letter];
    return i === MUT ? mix(c, CRIMSON, m) : c;
  }

  /* ---------- sizing ---------- */
  function resize() {
    var r = canvas.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = r.width; h = r.height;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    requestRender();
  }

  /* ---------- render ---------- */
  var geo = { R: 80, F: 560, gap: 15, cx: 0, cy: 0, s: 1 };

  function project(x, y, z) {
    var cp = Math.cos(pitch), sp = Math.sin(pitch);
    var y1 = y * cp - z * sp, z1 = y * sp + z * cp;
    var cr = Math.cos(roll), sr = Math.sin(roll);
    var x2 = x * cr - y1 * sr, y2 = x * sr + y1 * cr;
    var k = geo.F / (geo.F - z1);
    return { x: geo.cx + x2 * k, y: geo.cy + y2 * k, z: z1, k: k };
  }

  function pointAt(u, strand) {
    var y = (u - (N - 1) / 2) * geo.gap;
    var th = phase + u * TWIST + strand * Math.PI;
    return project(geo.R * Math.cos(th), y, geo.R * Math.sin(th));
  }

  function fadeAt(u) {
    return smooth((u + PAD) / 4) * smooth((N - 1 + PAD - u) / 4);
  }

  function depth(z) { return clamp((z + geo.R) / (2 * geo.R), 0, 1); }

  function segDist(x, y, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay;
    var l2 = dx * dx + dy * dy;
    var t = l2 ? clamp(((x - ax) * dx + (y - ay) * dy) / l2, 0, 1) : 0;
    var ex = ax + dx * t - x, ey = ay + dy * t - y;
    return Math.sqrt(ex * ex + ey * ey);
  }

  function render() {
    if (!w || !h) return;
    ctx.clearRect(0, 0, w, h);

    var s = Math.min(w / 480, h / 580);
    geo.s = s;
    geo.R = 96 * s;
    geo.F = geo.R * 7;
    geo.gap = (h * 0.82) / SPAN;
    geo.cx = w * 0.5;
    geo.cy = h * 0.47;

    var m = reduceMq.matches ? 1 : mutAmount(clock);
    var pulse = (clock * 0.85) % 1;

    /* drifting base letters in the background */
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (var q = 0; q < motes.length; q++) {
      var mo = motes[q];
      var yy = ((mo.y - clock * mo.speed) % 1 + 1) % 1;
      var edge = Math.min(yy, 1 - yy) * 6;
      var rgb = BASE_RGB[mo.ch];
      ctx.font = '500 ' + (mo.size * s) + 'px ' + MONO;
      ctx.fillStyle = 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + (mo.a * clamp(edge, 0, 1)) + ')';
      ctx.fillText(mo.ch, mo.x * w, yy * h);
    }

    /* project everything once */
    var back = [[], []];
    var total = Math.round(SPAN * SUB);
    for (var st = 0; st < 2; st++) {
      for (var j = 0; j <= total; j++) {
        var u = -PAD + j / SUB;
        var p = pointAt(u, st);
        p.f = fadeAt(u);
        back[st].push(p);
      }
    }
    var rungs = [];
    for (var i = 0; i < N; i++) {
      rungs.push({ a: pointAt(i, 0), b: pointAt(i, 1), c: project(0, (i - (N - 1) / 2) * geo.gap, 0), f: fadeAt(i) });
    }

    /* hover: nearest rung to the pointer */
    hover = -1;
    if (inside && !dragging) {
      var best = 12;
      for (var r = 0; r < N; r++) {
        if (rungs[r].f < 0.4) continue;
        var d = segDist(px, py, rungs[r].a.x, rungs[r].a.y, rungs[r].b.x, rungs[r].b.y);
        if (d < best) { best = d; hover = r; }
      }
    }

    /* build draw list, then paint back-to-front */
    var items = [];

    for (var t = 0; t < 2; t++) {
      (function (strand) {
        var pts = back[strand];
        for (var k = 0; k < pts.length - 1; k++) {
          (function (a, b) {
            var f = Math.min(a.f, b.f);
            if (f < 0.02) return;
            items.push({
              z: (a.z + b.z) / 2,
              draw: function () {
                var vis = f * (0.3 + 0.7 * depth((a.z + b.z) / 2));
                var kk = (a.k + b.k) / 2;
                ctx.lineCap = 'round';
                ctx.strokeStyle = tint(STRAND_RGB[strand], vis);
                ctx.lineWidth = 5.6 * s * kk;
                ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
                ctx.strokeStyle = tint(mix(STRAND_RGB[strand], WHITE, 0.6), vis);
                ctx.lineWidth = 1.5 * s * kk;
                ctx.beginPath(); ctx.moveTo(a.x - 0.9 * s * kk, a.y - 0.9 * s * kk); ctx.lineTo(b.x - 0.9 * s * kk, b.y - 0.9 * s * kk); ctx.stroke();
              }
            });
          })(pts[k], pts[k + 1]);
        }
      })(t);
    }

    for (var n = 0; n < N; n++) {
      (function (idx) {
        var rg = rungs[idx];
        if (rg.f < 0.02) return;
        var pair = baseAt(idx, m);
        var isHover = idx === hover;
        var isMut = idx === MUT;

        [rg.a, rg.b].forEach(function (P, side) {
          var letter = pair[side];
          var col = baseColor(letter, idx, m);
          var dP = depth(P.z);
          var vis = rg.f * (0.32 + 0.68 * dP);

          // rung half
          items.push({
            z: P.z * 0.9 - 0.5,
            draw: function () {
              ctx.lineCap = 'round';
              ctx.strokeStyle = tint(col, vis);
              ctx.lineWidth = (isHover ? 4.6 : 3.2) * s * P.k;
              ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(rg.c.x, rg.c.y); ctx.stroke();
            }
          });

          // base bubble with letter
          var bx = (P.x + rg.c.x) / 2, by = (P.y + rg.c.y) / 2;
          items.push({
            z: P.z * 0.5,
            draw: function () {
              var rad = (isHover ? 8.6 : 6.8) * s * P.k;
              if (isMut && m > 0.02) {
                ctx.lineWidth = 1.6 * s;
                ctx.strokeStyle = 'rgba(196,74,56,' + (0.55 * m * (1 - pulse) * rg.f) + ')';
                ctx.beginPath(); ctx.arc(bx, by, rad + pulse * 20 * s, 0, 6.2832); ctx.stroke();
                ctx.fillStyle = 'rgba(196,74,56,' + (0.14 * m * rg.f) + ')';
                ctx.beginPath(); ctx.arc(bx, by, rad + 5 * s, 0, 6.2832); ctx.fill();
              }
              if (isHover) {
                ctx.fillStyle = 'rgba(' + (col[0] | 0) + ',' + (col[1] | 0) + ',' + (col[2] | 0) + ',0.18)';
                ctx.beginPath(); ctx.arc(bx, by, rad + 6 * s, 0, 6.2832); ctx.fill();
              }
              ctx.fillStyle = tint(col, vis);
              ctx.beginPath(); ctx.arc(bx, by, rad, 0, 6.2832); ctx.fill();
              ctx.lineWidth = 1.4 * s * P.k;
              ctx.strokeStyle = 'rgba(255,255,255,' + (0.9 * rg.f) + ')';
              ctx.stroke();
              var fs = 8.8 * s * P.k * (isHover ? 1.2 : 1);
              if (fs >= 7 && dP > 0.3) {
                ctx.font = '600 ' + fs + 'px ' + MONO;
                ctx.fillStyle = 'rgba(255,255,255,' + clamp(rg.f * dP * 1.4, 0, 1) + ')';
                ctx.fillText(letter, bx, by + 0.5);
              }
            }
          });

          // backbone node where the rung meets the strand
          items.push({
            z: P.z + 0.3,
            draw: function () {
              ctx.fillStyle = tint(STRAND_RGB[side], rg.f * (0.35 + 0.65 * dP));
              ctx.beginPath(); ctx.arc(P.x, P.y, 3.9 * s * P.k, 0, 6.2832); ctx.fill();
              ctx.strokeStyle = 'rgba(255,255,255,' + (0.85 * rg.f) + ')';
              ctx.lineWidth = 1.2 * s * P.k;
              ctx.stroke();
            }
          });
        });
      })(n);
    }

    items.sort(function (a, b) { return a.z - b.z; });
    for (var z = 0; z < items.length; z++) items[z].draw();

    /* callout on the mutated pair */
    var mr = rungs[MUT];
    var right = mr.c.x + geo.R * mr.c.k + 150 * s < w - 6;
    var dir = right ? 1 : -1;
    var ex = mr.c.x + dir * (geo.R * 1.15 + 26 * s);
    var ey = mr.c.y - 30 * s;
    var cA = 0.35 + 0.65 * m;
    ctx.save();
    ctx.setLineDash([3, 3]);
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(196,74,56,' + (0.75 * cA) + ')';
    ctx.beginPath(); ctx.moveTo(mr.c.x, mr.c.y); ctx.lineTo(ex, ey); ctx.lineTo(ex + dir * 10, ey); ctx.stroke();
    ctx.restore();
    var ty = 11 * s + 1;
    ctx.textAlign = dir > 0 ? 'left' : 'right';
    var tx = ex + dir * 14;
    var l1 = m > 0.5 ? 'c.20A>T' : 'c.20  A';
    var l2 = m > 0.5 ? 'Glu \u2192 Val' : 'Glu';
    ctx.font = '600 ' + (12.5 * Math.max(s, 0.8)) + 'px ' + MONO;
    ctx.fillStyle = 'rgba(196,74,56,' + cA + ')';
    ctx.fillText(l1, tx, ey - ty * 0.55);
    ctx.font = '500 ' + (11 * Math.max(s, 0.8)) + 'px ' + MONO;
    ctx.fillStyle = 'rgba(23,32,28,' + (0.55 * cA + 0.15) + ')';
    ctx.fillText(l2, tx, ey + ty * 0.85);
    ctx.textAlign = 'center';

    /* hover read-out */
    if (hover >= 0) {
      var hp = baseAt(hover, m);
      var hc = rungs[hover].c;
      var label = hp[0] + ' \u2013 ' + hp[1] + '   pair ' + (hover + 1);
      ctx.font = '500 12px ' + MONO;
      var tw = ctx.measureText(label).width + 20;
      var bxp = clamp(hc.x - tw / 2, 4, w - tw - 4);
      var byp = clamp(hc.y - 40, 4, h - 30);
      ctx.fillStyle = 'rgba(255,255,255,0.96)';
      ctx.strokeStyle = 'rgba(15,22,19,0.18)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(bxp, byp, tw, 24, 4); else ctx.rect(bxp, byp, tw, 24);
      ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#17201c';
      ctx.fillText(label, bxp + tw / 2, byp + 12.5);
    }
  }

  /* ---------- loop ---------- */
  function step(dt) {
    clock += dt;
    if (!dragging) {
      phase += (reduceMq.matches ? 0 : BASE_SPEED + vel) * dt;
      vel *= Math.exp(-dt * 1.6);
    }
    var pT = inside ? (my - 0.5) * 0.5 : 0.12;
    var rT = -0.36 + (inside ? (mx - 0.5) * 0.14 : 0);
    var e = 1 - Math.exp(-dt * 4);
    pitch += (pT - pitch) * e;
    roll += (rT - roll) * e;
    render();
  }

  function frame(now) {
    if (!running) return;
    var dt = Math.min(0.05, (now - lastFrame) / 1000 || 0.016);
    lastFrame = now;
    step(dt);
    raf = requestAnimationFrame(frame);
  }
  function start() {
    if (running || reduceMq.matches || !visible || document.hidden) return;
    running = true;
    lastFrame = performance.now();
    raf = requestAnimationFrame(frame);
  }
  function stop() { running = false; cancelAnimationFrame(raf); }
  function requestRender() { if (!running) step(0); }

  /* ---------- input ---------- */
  function local(e) {
    var r = canvas.getBoundingClientRect();
    px = e.clientX - r.left; py = e.clientY - r.top;
    mx = px / r.width; my = py / r.height;
  }
  canvas.addEventListener('pointerdown', function (e) {
    dragging = true; lastX = e.clientX; lastT = performance.now(); vel = 0;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    canvas.classList.add('dragging');
  });
  canvas.addEventListener('pointermove', function (e) {
    inside = true; local(e);
    if (dragging) {
      var now = performance.now();
      var dx = e.clientX - lastX;
      phase += dx * 0.013;
      var dts = Math.max((now - lastT) / 1000, 0.008);
      vel = clamp((dx * 0.013) / dts - BASE_SPEED, -10, 10);
      lastX = e.clientX; lastT = now;
    }
    requestRender();
  });
  function release() { dragging = false; canvas.classList.remove('dragging'); }
  canvas.addEventListener('pointerup', release);
  canvas.addEventListener('pointercancel', release);
  canvas.addEventListener('pointerleave', function () { inside = false; hover = -1; requestRender(); });
  canvas.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowLeft') { phase -= 0.25; requestRender(); }
    if (e.key === 'ArrowRight') { phase += 0.25; requestRender(); }
  });

  /* ---------- lifecycle ---------- */
  if (window.ResizeObserver) new ResizeObserver(resize).observe(canvas);
  else window.addEventListener('resize', resize);

  if (window.IntersectionObserver) {
    new IntersectionObserver(function (entries) {
      visible = entries[0].isIntersecting;
      if (visible) { resize(); start(); } else stop();
    }).observe(canvas);
  } else { visible = true; }

  document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else start(); });
  if (reduceMq.addEventListener) reduceMq.addEventListener('change', function () { stop(); start(); requestRender(); });

  resize();
  start();
})();
