/* Stage 2 — Smith–Waterman local alignment with full traceback: O(n·m) */
(function (G) {
  "use strict";

  function smithWaterman(a, b, match, mismatch, gap) {
    var n = a.length, m = b.length;
    var H = new Array(n + 1);
    var T = new Array(n + 1); // 0 stop, 1 diag, 2 up, 3 left
    for (var i = 0; i <= n; i++) { H[i] = new Int32Array(m + 1); T[i] = new Uint8Array(m + 1); }

    var maxScore = 0, maxI = 0, maxJ = 0;
    for (var i = 1; i <= n; i++) {
      var ai = a[i - 1];
      for (var j = 1; j <= m; j++) {
        var diag = H[i - 1][j - 1] + (ai === b[j - 1] ? match : mismatch);
        var up = H[i - 1][j] + gap;
        var left = H[i][j - 1] + gap;
        var best = 0, dir = 0;
        if (diag > best) { best = diag; dir = 1; }
        if (up > best) { best = up; dir = 2; }
        if (left > best) { best = left; dir = 3; }
        H[i][j] = best;
        T[i][j] = dir;
        if (best > maxScore) { maxScore = best; maxI = i; maxJ = j; }
      }
    }

    var alignedA = [], alignedB = [], matchLine = [];
    var matches = 0, mismatches = 0, gaps = 0;
    var i = maxI, j = maxJ;
    while (i > 0 && j > 0 && H[i][j] !== 0) {
      var dir = T[i][j];
      if (dir === 1) {
        var ca = a[i - 1], cb = b[j - 1];
        alignedA.push(ca); alignedB.push(cb);
        if (ca === cb) { matchLine.push('m'); matches++; } else { matchLine.push('x'); mismatches++; }
        i--; j--;
      } else if (dir === 2) {
        alignedA.push(a[i - 1]); alignedB.push('-'); matchLine.push('g'); gaps++;
        i--;
      } else if (dir === 3) {
        alignedA.push('-'); alignedB.push(b[j - 1]); matchLine.push('g'); gaps++;
        j--;
      } else {
        break;
      }
    }
    alignedA.reverse(); alignedB.reverse(); matchLine.reverse();

    var startA = i, startB = j;
    var endA = maxI, endB = maxJ;
    var alignedLen = alignedA.length;
    var similarity = alignedLen > 0 ? (matches / alignedLen * 100) : 0;

    return {
      H: H, T: T, n: n, m: m,
      maxScore: maxScore, maxI: maxI, maxJ: maxJ,
      alignedA: alignedA.join(''), alignedB: alignedB.join(''), matchLine: matchLine,
      matches: matches, mismatches: mismatches, gaps: gaps,
      alignedLen: alignedLen, similarity: similarity,
      regionA: [startA + 1, endA], regionB: [startB + 1, endB]
    };
  }

  G.smithWaterman = smithWaterman;
})(window.GeneScan = window.GeneScan || {});
