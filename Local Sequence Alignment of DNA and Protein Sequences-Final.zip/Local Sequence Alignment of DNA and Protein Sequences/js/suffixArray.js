/* Stage 1a — Suffix array by prefix doubling: O(n log^2 n) */
(function (G) {
  "use strict";

  function buildSuffixArray(s) {
    var n = s.length;
    var sa = new Array(n);
    for (var i = 0; i < n; i++) sa[i] = i;
    var rank = new Array(n);
    for (var i = 0; i < n; i++) rank[i] = s.charCodeAt(i);
    var tmp = new Array(n);
    var k = 1;

    function cmp(a, b) {
      if (rank[a] !== rank[b]) return rank[a] - rank[b];
      var ra = (a + k < n) ? rank[a + k] : -1;
      var rb = (b + k < n) ? rank[b + k] : -1;
      return ra - rb;
    }

    while (k < n) {
      sa.sort(cmp);
      tmp[sa[0]] = 0;
      for (var i = 1; i < n; i++) {
        tmp[sa[i]] = tmp[sa[i - 1]] + (cmp(sa[i - 1], sa[i]) < 0 ? 1 : 0);
      }
      for (var i = 0; i < n; i++) rank[i] = tmp[i];
      if (rank[sa[n - 1]] === n - 1) break;
      k *= 2;
    }
    return { sa: sa, rank: rank };
  }

  G.buildSuffixArray = buildSuffixArray;
})(window.GeneScan = window.GeneScan || {});
