/* Module 4 — Edmonds–Karp max-flow (Ford–Fulkerson with BFS shortest augmenting paths).
   Pure algorithm: no drawing, no DOM. */
(function (G) {
  "use strict";

  function FlowNetwork(nodeNames, edgeDefs, source, sink) {
    this.names = nodeNames;
    this.defs = edgeDefs;
    this.source = source;
    this.sink = sink;
    this.reset();
  }

  FlowNetwork.prototype.reset = function () {
    var self = this;
    this.edges = [];
    this.graph = {};
    this.names.forEach(function (k) { self.graph[k] = []; });
    this.defs.forEach(function (e) {
      self.edges.push({ from: e[0], to: e[1], cap: e[2], flow: 0 });
      self.edges.push({ from: e[1], to: e[0], cap: 0, flow: 0 });
      self.graph[e[0]].push(self.edges.length - 2);
      self.graph[e[1]].push(self.edges.length - 1);
    });
  };

  // BFS in the residual graph; returns list of edge indices, or null if no path
  FlowNetwork.prototype.bfsPath = function () {
    var edges = this.edges, graph = this.graph, S = this.source, T = this.sink;
    var parent = {}, visited = {}, queue = [S];
    visited[S] = true;
    while (queue.length) {
      var u = queue.shift();
      if (u === T) break;
      graph[u].forEach(function (ei) {
        var e = edges[ei];
        if (!visited[e.to] && e.cap - e.flow > 0) {
          visited[e.to] = true; parent[e.to] = ei; queue.push(e.to);
        }
      });
    }
    if (!visited[T]) return null;
    var path = [], v = T;
    while (v !== S) { var ei = parent[v]; path.push(ei); v = edges[ei].from; }
    path.reverse();
    return path;
  };

  // Push the bottleneck along a path; returns the bottleneck value
  FlowNetwork.prototype.augment = function (path) {
    var edges = this.edges;
    var bottleneck = Math.min.apply(null, path.map(function (ei) { return edges[ei].cap - edges[ei].flow; }));
    path.forEach(function (ei) { edges[ei].flow += bottleneck; edges[ei ^ 1].flow -= bottleneck; });
    return bottleneck;
  };

  FlowNetwork.prototype.totalFlow = function () {
    var edges = this.edges, total = 0;
    this.graph[this.source].forEach(function (ei) { total += edges[ei].flow; });
    return total;
  };

  // Min cut = forward edges leaving the set reachable from the source in the residual graph
  FlowNetwork.prototype.minCutEdges = function () {
    var edges = this.edges, graph = this.graph;
    var visited = {}, queue = [this.source];
    visited[this.source] = true;
    while (queue.length) {
      var u = queue.shift();
      graph[u].forEach(function (ei) {
        var e = edges[ei];
        if (!visited[e.to] && e.cap - e.flow > 0) { visited[e.to] = true; queue.push(e.to); }
      });
    }
    var cut = [];
    for (var i = 0; i < edges.length; i += 2) {
      var e = edges[i];
      if (visited[e.from] && !visited[e.to]) cut.push(i);
    }
    return cut;
  };

  G.FlowNetwork = FlowNetwork;
})(window.GeneScan = window.GeneScan || {});
