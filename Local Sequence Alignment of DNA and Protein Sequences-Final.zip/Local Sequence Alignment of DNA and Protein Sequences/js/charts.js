/* Performance chart (canvas). UI only. Supports SW and NW canvases. */
(function (G) {
  "use strict";
  var $ = G.$;

  function drawPerfChartOn(canvasId, points, lineColor) {
    var canvas = $(canvasId);
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var W = canvas.width, H = canvas.height;
    var color = lineColor || '#0d9f7a';
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);

    var padL = 60, padR = 24, padT = 20, padB = 40;
    var plotW = W - padL - padR, plotH = H - padT - padB;

    if (!points.length) {
      ctx.fillStyle = 'rgba(18,26,23,0.4)';
      ctx.font = '13px monospace';
      ctx.fillText('run the benchmark to see results', padL, H / 2);
      return;
    }

    var maxX = Math.max.apply(null, points.map(function (p) { return p.n; }));
    var maxY = Math.max.apply(null, points.map(function (p) { return p.time; }));
    maxY = maxY * 1.15;

    function xPix(n) { return padL + (n / maxX) * plotW; }
    function yPix(t) { return padT + plotH - (t / maxY) * plotH; }

    ctx.strokeStyle = 'rgba(15,22,19,0.1)';
    ctx.lineWidth = 1;
    for (var g = 0; g <= 4; g++) {
      var gy = padT + plotH * g / 4;
      ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(W - padR, gy); ctx.stroke();
      ctx.fillStyle = 'rgba(18,26,23,0.45)';
      ctx.font = '10.5px monospace';
      ctx.fillText((maxY * (1 - g / 4)).toFixed(0) + 'ms', 6, gy + 3);
    }

    var last = points[points.length - 1];
    var c = last.time / (last.n * last.n);
    ctx.strokeStyle = 'rgba(18,26,23,0.35)';
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    for (var n = 0; n <= maxX; n += maxX / 80) {
      var t = c * n * n;
      var xx = xPix(n), yy = yPix(Math.min(t, maxY));
      if (n === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.strokeStyle = color;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    points.forEach(function (p, idx) {
      var xx = xPix(p.n), yy = yPix(p.time);
      if (idx === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
    });
    ctx.stroke();

    points.forEach(function (p) {
      var xx = xPix(p.n), yy = yPix(p.time);
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(xx, yy, 4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(18,26,23,0.55)';
      ctx.font = '10.5px monospace';
      ctx.fillText(p.n, xx - 10, H - padB + 16);
    });

    ctx.fillStyle = 'rgba(18,26,23,0.5)';
    ctx.font = '11px monospace';
    ctx.fillText('sequence length (n = m)', padL, H - 6);
  }

  function drawPerfChart(points) {
    drawPerfChartOn('perfCanvas', points, '#0d9f7a');
  }

  function drawNwPerfChart(points) {
    drawPerfChartOn('nwPerfCanvas', points, '#c47d12');
  }

  G.drawPerfChart = drawPerfChart;
  G.drawNwPerfChart = drawNwPerfChart;
})(window.GeneScan = window.GeneScan || {});
