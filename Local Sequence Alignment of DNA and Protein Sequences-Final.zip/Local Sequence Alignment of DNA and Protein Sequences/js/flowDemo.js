/* Module 4 live demo: drawing + buttons around the FlowNetwork (edmondsKarp.js). */
(function (G) {
  "use strict";
  var $ = G.$;

  var flowNodes = {
    S: { x: 70, y: 190, label: 'S' }, A: { x: 300, y: 90, label: 'A' }, B: { x: 300, y: 290, label: 'B' },
    C: { x: 600, y: 90, label: 'C' }, D: { x: 600, y: 290, label: 'D' }, T: { x: 830, y: 190, label: 'T' }
  };
  var edgeDefs = [
    ['S', 'A', 16], ['S', 'B', 13], ['A', 'B', 10], ['B', 'A', 4], ['A', 'C', 12],
    ['C', 'B', 9], ['B', 'D', 14], ['D', 'C', 7], ['C', 'T', 20], ['D', 'T', 4]
  ];

  var net = new G.FlowNetwork(Object.keys(flowNodes), edgeDefs, 'S', 'T');
  var done = false;

  function drawFlow(highlightPath, cutEdges) {
    var edges = net.edges;
    var canvas = $('flowCanvas'), ctx = canvas.getContext('2d');
    var W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);

    var pathSet = {}; (highlightPath || []).forEach(function (ei) { pathSet[ei] = true; });
    var cutSet = {}; (cutEdges || []).forEach(function (ei) { cutSet[ei] = true; });

    for (var i = 0; i < edges.length; i += 2) {
      var e = edges[i];
      var n1 = flowNodes[e.from], n2 = flowNodes[e.to];
      var color = 'rgba(18,26,23,0.28)';
      if (cutSet[i]) color = '#c44a38'; else if (pathSet[i]) color = '#0d9f7a'; else if (e.flow >= e.cap) color = 'rgba(196,74,56,0.55)';
      ctx.strokeStyle = color; ctx.lineWidth = pathSet[i] ? 3 : 1.6;
      var dx = n2.x - n1.x, dy = n2.y - n1.y, len = Math.sqrt(dx * dx + dy * dy);
      var ux = dx / len, uy = dy / len;
      var sx = n1.x + ux * 26, sy = n1.y + uy * 26, ex = n2.x - ux * 26, ey = n2.y - uy * 26;
      ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();
      var ang = Math.atan2(ey - sy, ex - sx);
      ctx.beginPath(); ctx.moveTo(ex, ey);
      ctx.lineTo(ex - 10 * Math.cos(ang - 0.3), ey - 10 * Math.sin(ang - 0.3));
      ctx.lineTo(ex - 10 * Math.cos(ang + 0.3), ey - 10 * Math.sin(ang + 0.3));
      ctx.closePath(); ctx.fillStyle = color; ctx.fill();
      ctx.fillStyle = 'rgba(18,26,23,0.7)'; ctx.font = '12px monospace';
      ctx.fillText(e.flow + '/' + e.cap, (sx + ex) / 2 - 12, (sy + ey) / 2 - 8);
    }
    Object.keys(flowNodes).forEach(function (k) {
      var n = flowNodes[k];
      ctx.beginPath(); ctx.arc(n.x, n.y, 24, 0, Math.PI * 2);
      ctx.fillStyle = (k === 'S' || k === 'T') ? '#0d9f7a' : '#f0f2f0';
      ctx.fill(); ctx.strokeStyle = 'rgba(18,26,23,0.35)'; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.fillStyle = (k === 'S' || k === 'T') ? '#ffffff' : '#121a17';
      ctx.font = '600 15px Inter, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(n.label, n.x, n.y);
    });
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  }

  $('btnFlowStep').addEventListener('click', function () {
    if (done) return;
    var path = net.bfsPath();
    if (!path) {
      done = true;
      var cut = net.minCutEdges();
      var total = net.totalFlow();
      drawFlow(null, cut);
      $('flowStatus').textContent = 'no augmenting path left \u2014 max flow = ' + total + ', min cut capacity = ' + total + '.';
      $('btnFlowStep').disabled = true;
      return;
    }
    var bottleneck = net.augment(path);
    drawFlow(path, null);
    var names = ['S'].concat(path.map(function (ei) { return net.edges[ei].to; }));
    $('flowStatus').textContent = 'augmented ' + names.join('\u2192') + ' by ' + bottleneck + ' \u2014 flow = ' + net.totalFlow() + '.';
  });

  $('btnFlowReset').addEventListener('click', function () {
    net.reset(); done = false; $('btnFlowStep').disabled = false;
    $('flowStatus').textContent = 'flow = 0 \u2014 click to begin.';
    drawFlow(null, null);
  });

  drawFlow(null, null);
})(window.GeneScan = window.GeneScan || {});
