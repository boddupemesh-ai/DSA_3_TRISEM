/* Stage 3 — Needleman–Wunsch global alignment with full traceback: O(n·m)
   Aligns both sequences from end to end (no local zero-floor). */
(function (G) {
  "use strict";

  function needlemanWunsch(a, b, match, mismatch, gap) {
    var n = a.length, m = b.length;
    var H = new Array(n + 1);
    var T = new Array(n + 1); // 1 diag, 2 up, 3 left
    for (var i = 0; i <= n; i++) {
      H[i] = new Int32Array(m + 1);
      T[i] = new Uint8Array(m + 1);
    }

    // initialise first row / column with gap penalties (global)
    for (var i = 1; i <= n; i++) {
      H[i][0] = i * gap;
      T[i][0] = 2; // up
    }
    for (var j = 1; j <= m; j++) {
      H[0][j] = j * gap;
      T[0][j] = 3; // left
    }

    for (var i = 1; i <= n; i++) {
      var ai = a[i - 1];
      for (var j = 1; j <= m; j++) {
        var diag = H[i - 1][j - 1] + (ai === b[j - 1] ? match : mismatch);
        var up = H[i - 1][j] + gap;
        var left = H[i][j - 1] + gap;
        var best = diag, dir = 1;
        if (up > best) { best = up; dir = 2; }
        if (left > best) { best = left; dir = 3; }
        H[i][j] = best;
        T[i][j] = dir;
      }
    }

    var alignedA = [], alignedB = [], matchLine = [];
    var matches = 0, mismatches = 0, gaps = 0;
    var i = n, j = m;
    while (i > 0 || j > 0) {
      var dir = T[i][j];
      if (i > 0 && j > 0 && dir === 1) {
        var ca = a[i - 1], cb = b[j - 1];
        alignedA.push(ca); alignedB.push(cb);
        if (ca === cb) { matchLine.push('m'); matches++; }
        else { matchLine.push('x'); mismatches++; }
        i--; j--;
      } else if (i > 0 && (j === 0 || dir === 2)) {
        alignedA.push(a[i - 1]); alignedB.push('-'); matchLine.push('g'); gaps++;
        i--;
      } else if (j > 0 && (i === 0 || dir === 3)) {
        alignedA.push('-'); alignedB.push(b[j - 1]); matchLine.push('g'); gaps++;
        j--;
      } else {
        break;
      }
    }
    alignedA.reverse(); alignedB.reverse(); matchLine.reverse();

    var alignedLen = alignedA.length;
    var similarity = alignedLen > 0 ? (matches / alignedLen * 100) : 0;
    var score = H[n][m];

    return {
      H: H, T: T, n: n, m: m,
      maxScore: score, maxI: n, maxJ: m,
      alignedA: alignedA.join(''), alignedB: alignedB.join(''), matchLine: matchLine,
      matches: matches, mismatches: mismatches, gaps: gaps,
      alignedLen: alignedLen, similarity: similarity,
      regionA: [1, n], regionB: [1, m]
    };
  }

  G.needlemanWunsch = needlemanWunsch;
})(window.GeneScan = window.GeneScan || {});
