/* Stage 1 — Longest exact common substring of A and B,
   using the combined suffix array + Kasai LCP scan. */
(function (G) {
  "use strict";

  function longestCommonSubstring(a, b) {
    var SEP1 = '\u0001', SEP2 = '\u0002';
    var combined = a + SEP1 + b + SEP2;
    var lenA = a.length;
    var built = G.buildSuffixArray(combined);
    var lcp = G.kasaiLCP(combined, built.sa, built.rank);
    var n = combined.length;
    var best = 0, bestPosA = -1, bestPosB = -1;

    for (var i = 1; i < n; i++) {
      var p1 = built.sa[i - 1], p2 = built.sa[i];
      var side1 = p1 < lenA ? 'A' : 'B';
      var side2 = p2 < lenA ? 'A' : 'B';
      if (side1 !== side2 && lcp[i] > best) {
        best = lcp[i];
        if (side1 === 'A') { bestPosA = p1; bestPosB = p2 - lenA - 1; }
        else { bestPosA = p2; bestPosB = p1 - lenA - 1; }
      }
    }
    return {
      length: best,
      substring: best > 0 ? a.substr(bestPosA, best) : '',
      posA: bestPosA,
      posB: bestPosB
    };
  }

  G.longestCommonSubstring = longestCommonSubstring;
})(window.GeneScan = window.GeneScan || {});
