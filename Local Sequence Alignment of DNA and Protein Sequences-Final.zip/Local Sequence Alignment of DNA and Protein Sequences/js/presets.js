/* Preset sequence pairs.
   Each DNA pair is exactly 2000 bases per sequence: the original short motif
   (with its real mutation) followed by a fixed, seeded pseudo-random background,
   so the sequences are identical every time the page loads. */
(function (G) {
  "use strict";

  var LEN = 2000;

  // small deterministic PRNG (mulberry32) -> same background on every load
  function makeRng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function background(length, seed) {
    var rng = makeRng(seed), out = [], bases = 'ACGT';
    for (var i = 0; i < length; i++) out.push(bases[Math.floor(rng() * 4)]);
    return out.join('');
  }

  // motif + shared background, padded/trimmed so the total is exactly LEN
  function extend(motif, bg) { return motif + bg.substr(0, LEN - motif.length); }

  var bgSickle = background(LEN, 1001);
  var bgCF = background(LEN, 2002);
  var bgTay = background(LEN, 3003);

  var PRESETS = [
    {
      id: 'sickle-dna', label: 'Sickle cell \u2014 DNA',
      seqType: 'DNA',
      a: extend('ATGGTGCACCTGACTCCTGAGGAGAAGTCTGCCGTTACTGCCCTGTGGGGCAAGGTGAA', bgSickle),
      b: extend('ATGGTGCACCTGACTCCTGTGGAGAAGTCTGCCGTTACTGCCCTGTGGGGCAAGGTGAA', bgSickle),
      match: 2, mismatch: -1, gap: -2,
      note: 'HBB gene, first 20 codons, followed by a fixed 2,000-base background. A single A\u2192T substitution at codon 7 (GAG\u2192GTG) \u2014 the classic sickle-cell point mutation.'
    },
    {
      id: 'sickle-protein', label: 'Sickle cell \u2014 protein',
      seqType: 'PROTEIN',
      a: 'MVHLTPEEKSAVTALWGKV',
      b: 'MVHLTPVEKSAVTALWGKV',
      match: 1, mismatch: -1, gap: -2,
      note: 'Beta-globin fragment. Glu6 becomes Val6 \u2014 the amino-acid consequence of the DNA mutation above.'
    },
    {
      id: 'cf-deletion', label: 'Cystic fibrosis \u2014 deletion (illustrative)',
      seqType: 'DNA',
      a: extend('GAAAATATCATTTTTGGTGTTTCCTATGATGAATATAGATACAGAAGCGTC', bgCF),
      b: extend('GAAAATATCATTGGTGTTTCCTATGATGAATATAGATACAGAAGCGTC', bgCF),
      match: 2, mismatch: -1, gap: -2,
      note: 'An in-frame 3-base deletion modelled on the CFTR \u0394F508 mutation, inside a 2,000-base sequence \u2014 illustrative, not the literal clinical sequence.'
    },
    {
      id: 'tay-sachs', label: 'Tay-Sachs style \u2014 synthetic',
      seqType: 'DNA',
      a: extend('TTGAGCCTGGAGATCCTGACCAACCTGGTCATCTCCGACAAAGGCATCGT', bgTay),
      b: extend('TTGAGCCTGGAGATCCTGACCTACCTGGTCATCTCCGACGGGAAAGGCATCGT', bgTay),
      match: 2, mismatch: -1, gap: -2,
      note: 'A synthetic 2,000-base reference/patient pair with one substitution and a small insertion, in the style of the project\'s batch-generated diseases.'
    },
    {
      id: 'custom', label: 'Custom sequences',
      seqType: 'DNA',
      a: '', b: '',
      match: 2, mismatch: -1, gap: -2,
      note: 'Paste your own DNA or protein sequences (up to 2,000 characters each).'
    }
  ];

  G.PRESETS = PRESETS;
})(window.GeneScan = window.GeneScan || {});
