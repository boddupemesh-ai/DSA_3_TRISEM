/* Rendering helpers: alignment view, variant table, DP-matrix view. UI only. */
(function (G) {
  "use strict";

  var $ = G.$ = function (id) { return document.getElementById(id); };

  function renderAlignmentInto(blockId, res) {
    var block = $(blockId);
    if (!block) return;
    block.innerHTML = '';
    var A = res.alignedA, B = res.alignedB, M = res.matchLine;
    var chunk = 60;
    for (var start = 0; start < A.length; start += chunk) {
      var endc = Math.min(start + chunk, A.length);
      var aLine = document.createElement('div');
      aLine.className = 'align-line a';
      var mLine = document.createElement('div');
      mLine.className = 'align-line m';
      var bLine = document.createElement('div');
      bLine.className = 'align-line b';

      var aHtml = '<span class="idx">ref</span>', mHtml = '<span class="idx"></span>', bHtml = '<span class="idx">pat</span>';
      for (var k = start; k < endc; k++) {
        var t = M[k];
        var cls = t === 'm' ? 'ch-match' : (t === 'x' ? 'ch-mismatch' : 'ch-gap');
        aHtml += '<span class="' + cls + '">' + A[k] + '</span>';
        bHtml += '<span class="' + cls + '">' + B[k] + '</span>';
        mHtml += (t === 'm' ? '<span class="ch-match">|</span>' : (t === 'x' ? '<span class="ch-mismatch">&middot;</span>' : ' '));
      }
      aLine.innerHTML = aHtml; mLine.innerHTML = mHtml; bLine.innerHTML = bHtml;
      block.appendChild(aLine); block.appendChild(mLine); block.appendChild(bLine);
      if (endc < A.length) {
        var spacer = document.createElement('div'); spacer.style.height = '10px';
        block.appendChild(spacer);
      }
    }
  }

  function renderAlignment(res) {
    renderAlignmentInto('alignBlock', res);
  }

  function renderMutations(res) {
    var content = $('mutContent');
    var variants = [];
    var ai = res.regionA[0] - 1, bi = res.regionB[0] - 1;
    for (var k = 0; k < res.alignedA.length; k++) {
      var ca = res.alignedA[k], cb = res.alignedB[k];
      if (res.matchLine[k] === 'x') {
        variants.push({ pos: ai + 1, ref: ca, pat: cb, kind: 'sub' });
      } else if (res.matchLine[k] === 'g') {
        if (ca === '-') variants.push({ pos: ai + 1, ref: '-', pat: cb, kind: 'ins' });
        else variants.push({ pos: ai + 1, ref: ca, pat: '-', kind: 'del' });
      }
      if (ca !== '-') ai++;
      if (cb !== '-') bi++;
    }
    if (!variants.length) {
      content.innerHTML = '<p style="font-size:13.5px;color:var(--text-mid);margin:0;">No mismatches or gaps inside the aligned region \u2014 the patient sample matches the reference exactly here.</p>';
      return;
    }
    var html = '<table class="mut-table"><tr><th>Position (ref)</th><th>Reference</th><th>Patient</th><th>Type</th></tr>';
    variants.slice(0, 40).forEach(function (v) {
      var tag = v.kind === 'sub' ? '<span class="tag-chip sub">substitution</span>' : (v.kind === 'ins' ? '<span class="tag-chip gap">insertion</span>' : '<span class="tag-chip gap">deletion</span>');
      html += '<tr><td class="pos">' + v.pos + '</td><td>' + v.ref + '</td><td>' + v.pat + '</td><td>' + tag + '</td></tr>';
    });
    html += '</table>';
    if (variants.length > 40) html += '<p style="font-size:12px;color:var(--text-low);margin-top:8px;">showing first 40 of ' + variants.length + ' variant positions</p>';
    content.innerHTML = html;
  }

  function renderMatrix(res) {
    var wrap = $('matrixWrap');
    wrap.innerHTML = '';
    var n = res.n, m = res.m;
    $('matrixInfo').textContent = (n + 1) + ' \u00d7 ' + (m + 1) + ' cells';

    // reconstruct traceback path cells
    var pathSet = {};
    var i = res.maxI, j = res.maxJ;
    while (i > 0 && j > 0 && res.H[i][j] !== 0) {
      pathSet[i + '_' + j] = true;
      var dir = res.T[i][j];
      if (dir === 1) { i--; j--; } else if (dir === 2) { i--; } else if (dir === 3) { j--; } else break;
    }

    if (n <= 40 && m <= 40) {
      var table = document.createElement('table');
      table.className = 'hmatrix';
      var head = '<tr><th></th><th></th>';
      for (var jj = 0; jj < m; jj++) head += '<th>' + '\u00b7' + '</th>';
      head += '</tr>';
      table.innerHTML = head;
      for (var ii = 0; ii <= n; ii++) {
        var row = document.createElement('tr');
        var rowHtml = '<th></th>';
        for (var jj = 0; jj <= m; jj++) {
          var val = res.H[ii][jj];
          var cls = '';
          if (ii === res.maxI && jj === res.maxJ) cls = 'peak';
          else if (pathSet[ii + '_' + jj]) cls = 'path';
          rowHtml += '<td class="' + cls + '">' + val + '</td>';
        }
        row.innerHTML = rowHtml;
        table.appendChild(row);
      }
      wrap.appendChild(table);
      return;
    }

    // canvas heatmap for larger matrices (pixel buffer: fast even for 2001 x 2001)
    var canvas = document.createElement('canvas');
    var cw = Math.floor(Math.min(900, wrap.clientWidth || 900));
    var ch = Math.floor(Math.max(220, Math.min(560, Math.round(cw * (n + 1) / (m + 1)))));
    canvas.width = cw; canvas.height = ch;
    canvas.style.width = '100%'; canvas.style.display = 'block';
    wrap.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    var cellW = cw / (m + 1), cellH = ch / (n + 1);
    var maxScore = res.maxScore || 1;

    var img = ctx.createImageData(cw, ch);
    var d = img.data;
    var bestT = new Float32Array(cw * ch);
    for (var p = 0; p < cw * ch; p++) { d[p * 4] = 248; d[p * 4 + 1] = 250; d[p * 4 + 2] = 249; d[p * 4 + 3] = 255; }

    var wdt = Math.max(1, Math.ceil(cellW)), hgt = Math.max(1, Math.ceil(cellH));
    for (var ii = 0; ii <= n; ii++) {
      var y0 = Math.floor(ii * cellH);
      var rowH = res.H[ii];
      for (var jj = 0; jj <= m; jj++) {
        var v = rowH[jj];
        if (v <= 0) continue;
        var t = Math.min(1, v / maxScore);
        var x0 = Math.floor(jj * cellW);
        var r = Math.round(200 - t * 160), g = Math.round(230 - t * 70), bl = Math.round(210 - t * 90);
        for (var yy = y0; yy < y0 + hgt && yy < ch; yy++) {
          for (var xx = x0; xx < x0 + wdt && xx < cw; xx++) {
            var idx = yy * cw + xx;
            if (t <= bestT[idx]) continue;
            bestT[idx] = t;
            d[idx * 4] = r; d[idx * 4 + 1] = g; d[idx * 4 + 2] = bl;
          }
        }
      }
    }
    ctx.putImageData(img, 0, 0);

    // traceback path
    ctx.strokeStyle = '#f0ab3d';
    ctx.lineWidth = Math.max(1.4, Math.min(cellW, cellH) * 0.7);
    ctx.beginPath();
    var pi = res.maxI, pj = res.maxJ;
    ctx.moveTo((pj + 0.5) * cellW, (pi + 0.5) * cellH);
    var guard = 0;
    while (pi > 0 && pj > 0 && res.H[pi][pj] !== 0 && guard < (n + m + 2)) {
      var dir2 = res.T[pi][pj];
      if (dir2 === 1) { pi--; pj--; } else if (dir2 === 2) { pi--; } else if (dir2 === 3) { pj--; } else break;
      ctx.lineTo((pj + 0.5) * cellW, (pi + 0.5) * cellH);
      guard++;
    }
    ctx.stroke();

    // peak marker
    ctx.fillStyle = '#39d6ab';
    ctx.beginPath();
    ctx.arc((res.maxJ + 0.5) * cellW, (res.maxI + 0.5) * cellH, Math.max(2, Math.min(cellW, cellH)), 0, Math.PI * 2);
    ctx.fill();
  }

  G.renderAlignment = renderAlignment;
  G.renderAlignmentInto = renderAlignmentInto;
  G.renderMutations = renderMutations;
  G.renderMatrix = renderMatrix;
})(window.GeneScan = window.GeneScan || {});
