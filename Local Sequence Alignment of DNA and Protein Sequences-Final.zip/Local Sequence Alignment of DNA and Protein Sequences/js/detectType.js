/* Input cleaning + DNA / PROTEIN / INVALID classification */
(function (G) {
  "use strict";

  var DNA_RE = /^[ACGTN]+$/;
  var PROTEIN_RE = /^[ACDEFGHIKLMNPQRSTVWY]+$/;

  function detectType(raw) {
    var s = raw.toUpperCase().replace(/\s+/g, '');
    if (!s.length) return { type: 'EMPTY', clean: '' };
    if (DNA_RE.test(s)) return { type: 'DNA', clean: s };
    if (PROTEIN_RE.test(s)) return { type: 'PROTEIN', clean: s };
    var badIdx = -1, badChar = '';
    for (var i = 0; i < s.length; i++) {
      if (!/[A-Z]/.test(s[i])) { badIdx = i; badChar = s[i]; break; }
    }
    if (badIdx === -1) {
      for (var i = 0; i < s.length; i++) {
        if (!DNA_RE.test(s[i]) && !PROTEIN_RE.test(s[i])) { badIdx = i; badChar = s[i]; break; }
      }
    }
    return { type: 'INVALID', clean: s, badIdx: badIdx, badChar: badChar };
  }

  G.detectType = detectType;
})(window.GeneScan = window.GeneScan || {});
