/* Page wiring: SPA router, presets, badges, run alignment, batch screen, benchmark. */
(function (G) {
  "use strict";
  var $ = G.$;
  var PRESETS = G.PRESETS;

  var seqA = $('seqA'), seqB = $('seqB');
  var badgeA = $('badgeA'), badgeB = $('badgeB');
  var errA = $('errA'), errB = $('errB');
  var presetRow = $('presetRow');

  /* ---------- SPA page router (nav opens pages, does not scroll) ---------- */
  var PAGES = ['home', 'pipeline', 'lab', 'performance', 'tech', 'flow'];

  function showPage(name) {
    if (PAGES.indexOf(name) === -1) name = 'home';
    document.querySelectorAll('.page').forEach(function (el) {
      el.classList.toggle('active', el.getAttribute('data-page') === name);
    });
    document.querySelectorAll('.navlinks a').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-page') === name);
    });
    window.scrollTo(0, 0);
    // keep URL in sync so backend routes and refresh work
    var path = name === 'home' ? '/' : '/' + name;
    if (window.location.pathname !== path) {
      try { history.pushState({ page: name }, '', path); } catch (e) {}
    }
  }

  function pageFromPath() {
    var p = (window.location.pathname || '/').replace(/\/+$/, '') || '/';
    if (p === '/' || p === '/index.html') return 'home';
    var name = p.replace(/^\//, '').split('/')[0];
    return PAGES.indexOf(name) !== -1 ? name : 'home';
  }

  document.addEventListener('click', function (e) {
    // Only nav links / CTA buttons — ignore .page section wrappers
    // (clicks inside Network Flow were hitting data-page on the section and scrolling to top)
    var link = e.target.closest('a[data-page], button[data-page]');
    if (!link) return;
    if (link.classList.contains('page')) return;
    var name = link.getAttribute('data-page');
    if (!name || PAGES.indexOf(name) === -1) return;
    e.preventDefault();
    showPage(name);
  });

  window.addEventListener('popstate', function () {
    showPage(pageFromPath());
  });

  /* ---------- presets & badges ---------- */
  function renderPresets() {
    PRESETS.forEach(function (p) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-outline btn-small';
      b.textContent = p.label;
      b.dataset.id = p.id;
      b.addEventListener('click', function () { applyPreset(p); });
      presetRow.appendChild(b);
    });
  }
  function applyPreset(p) {
    seqA.value = p.a; seqB.value = p.b;
    $('scMatch').value = p.match; $('scMismatch').value = p.mismatch; $('scGap').value = p.gap;
    updateBadges();
    $('runStatus').textContent = p.note;
    $('results').classList.remove('show');
  }

  function badgeFor(el) {
    var info = G.detectType(el.value);
    if (info.type === 'EMPTY') return { text: '\u2014', cls: '' };
    if (info.type === 'DNA') return { text: 'DNA', cls: 'dna' };
    if (info.type === 'PROTEIN') return { text: 'PROTEIN', cls: 'protein' };
    return { text: 'INVALID', cls: 'bad' };
  }
  function updateBadges() {
    var ba = badgeFor(seqA), bb = badgeFor(seqB);
    badgeA.textContent = ba.text; badgeA.className = 'type-badge ' + ba.cls;
    badgeB.textContent = bb.text; badgeB.className = 'type-badge ' + bb.cls;

    var ia = G.detectType(seqA.value), ib = G.detectType(seqB.value);
    errA.textContent = ia.type === 'INVALID' ? ('character "' + ia.badChar + '" at position ' + (ia.badIdx + 1) + ' is not valid DNA or protein.') : '';
    errB.textContent = ib.type === 'INVALID' ? ('character "' + ib.badChar + '" at position ' + (ib.badIdx + 1) + ' is not valid DNA or protein.') : '';
  }
  seqA.addEventListener('input', updateBadges);
  seqB.addEventListener('input', updateBadges);

  $('btnDefaults').addEventListener('click', function () {
    var ia = G.detectType(seqA.value);
    if (ia.type === 'PROTEIN') { $('scMatch').value = 1; $('scMismatch').value = -1; $('scGap').value = -2; }
    else { $('scMatch').value = 2; $('scMismatch').value = -1; $('scGap').value = -2; }
  });

  /* ---------- run alignment (Stage 1 + Stage 2 + Stage 3) ---------- */
  function runAlignment() {
    var ia = G.detectType(seqA.value), ib = G.detectType(seqB.value);
    updateBadges();
    if (ia.type === 'EMPTY' || ib.type === 'EMPTY') {
      $('runStatus').textContent = 'enter both a reference and a patient sequence.';
      return;
    }
    if (ia.type === 'INVALID' || ib.type === 'INVALID') {
      $('runStatus').textContent = 'fix the invalid characters highlighted above before running.';
      return;
    }
    var a = ia.clean, b = ib.clean;
    var match = parseFloat($('scMatch').value) || 0;
    var mismatch = parseFloat($('scMismatch').value) || 0;
    var gap = parseFloat($('scGap').value) || 0;

    $('runStatus').textContent = 'running\u2026';

    setTimeout(function () {
      var t0 = performance.now();
      var lcs = G.longestCommonSubstring(a, b);
      var t1 = performance.now();
      var t2s = performance.now();
      var res = G.smithWaterman(a, b, match, mismatch, gap);
      var t2 = performance.now();
      var t3s = performance.now();
      var nw = G.needlemanWunsch(a, b, match, mismatch, gap);
      var t3 = performance.now();

      $('t1time').textContent = (t1 - t0).toFixed(2) + ' ms';
      $('t2time').textContent = (t2 - t2s).toFixed(2) + ' ms';
      if ($('t3time')) $('t3time').textContent = (t3 - t3s).toFixed(2) + ' ms';

      $('lcsSeq').textContent = lcs.length > 0 ? lcs.substring : '(no exact match found)';
      $('lcsMeta').innerHTML = lcs.length > 0
        ? ('length: ' + lcs.length + ' characters<br>reference position: ' + (lcs.posA + 1) + '&ndash;' + (lcs.posA + lcs.length) + '<br>patient position: ' + (lcs.posB + 1) + '&ndash;' + (lcs.posB + lcs.length))
        : 'the two sequences share no exact common substring.';

      $('statScore').textContent = res.maxScore;
      $('statMatches').textContent = res.matches;
      $('statMismatches').textContent = res.mismatches;
      $('statGaps').textContent = res.gaps;
      $('statSimilarity').textContent = res.similarity.toFixed(1) + '%';
      $('statLen').textContent = res.alignedLen;
      $('statRegionA').textContent = res.alignedLen ? (res.regionA[0] + '\u2013' + res.regionA[1]) : '\u2014';
      $('statRegionB').textContent = res.alignedLen ? (res.regionB[0] + '\u2013' + res.regionB[1]) : '\u2014';

      G.renderAlignment(res);
      G.renderMutations(res);
      G.renderMatrix(res);

      // Stage 3 — Needleman–Wunsch global
      if ($('nwScore')) {
        $('nwScore').textContent = nw.maxScore;
        $('nwMatches').textContent = nw.matches;
        $('nwMismatches').textContent = nw.mismatches;
        $('nwGaps').textContent = nw.gaps;
        $('nwSimilarity').textContent = nw.similarity.toFixed(1) + '%';
        $('nwLen').textContent = nw.alignedLen;
        G.renderAlignmentInto('nwAlignBlock', nw);
      }

      $('results').classList.add('show');
      $('runStatus').textContent = 'done \u2014 reference is ' + a.length + ' chars, patient is ' + b.length + ' chars.';

      window._lastAlignment = res;
      window._lastNW = nw;
      window._lastSeqs = { a: a, b: b };
    }, 20);
  }
  $('btnRun').addEventListener('click', runAlignment);

  $('btnCopy').addEventListener('click', function () {
    var res = window._lastAlignment;
    if (!res) return;
    var text = 'reference: ' + res.alignedA + '\npatient:   ' + res.alignedB + '\nscore: ' + res.maxScore + '  similarity: ' + res.similarity.toFixed(1) + '%';
    try {
      navigator.clipboard.writeText(text).then(function () {
        $('runStatus').textContent = 'alignment copied to clipboard.';
      }).catch(function () {});
    } catch (e) {}
  });

  /* ---------- batch screen ---------- */
  function renderBatchRows(rows, flaggedCount, total) {
    var html = '<table class="batch"><tr><th>Sample ID</th><th>Length</th><th>Score</th><th>Similarity</th><th>Status</th></tr>';
    rows.forEach(function (r) {
      html += '<tr><td>' + r.id + '</td><td>' + r.len + '</td><td>' + r.score + '</td><td>' + r.sim.toFixed(1) + '%</td><td class="' + (r.flagged ? 'status-flag' : 'status-clear') + '">' + (r.flagged ? 'mutation detected' : 'clear') + '</td></tr>';
    });
    html += '</table>';
    $('batchWrap').innerHTML = html;
    $('batchStatus').textContent = flaggedCount + ' of ' + total + ' samples flagged.';
  }

  $('btnBatch').addEventListener('click', function () {
    var ia = G.detectType(seqA.value);
    if (ia.type !== 'DNA' && ia.type !== 'PROTEIN') {
      $('batchStatus').textContent = 'load a valid reference sequence first.';
      return;
    }
    var alphabet = ia.type === 'DNA' ? 'ACGT' : 'ACDEFGHIKLMNPQRSTVWY';
    var ref = ia.clean;
    var match = parseFloat($('scMatch').value) || 2, mismatch = parseFloat($('scMismatch').value) || -1, gap = parseFloat($('scGap').value) || -2;
    var TOTAL = 25, rows = [];

    $('btnBatch').disabled = true;

    // one sample per tick so the page stays responsive on 2,000-base references
    function step(idx) {
      if (idx > TOTAL) {
        var flaggedCount = rows.filter(function (r) { return r.flagged; }).length;
        renderBatchRows(rows, flaggedCount, TOTAL);
        $('btnBatch').disabled = false;
        return;
      }
      $('batchStatus').textContent = 'screening sample ' + idx + ' of ' + TOTAL + '\u2026';
      setTimeout(function () {
        var sample = G.mutateSequence(ref, alphabet);
        var r = G.smithWaterman(ref, sample, match, mismatch, gap);
        var flagged = (r.mismatches + r.gaps) > 0;
        rows.push({ id: 'SIM-' + String(idx).padStart(3, '0'), len: sample.length, sim: r.similarity, score: r.maxScore, flagged: flagged });
        step(idx + 1);
      }, 0);
    }
    step(1);
  });

  /* ---------- performance benchmarks (SW + NW, separate) ---------- */
  function makePair(len) {
    var seqRef = G.randomDNA(len);
    var chars = seqRef.split('');
    for (var k = 0; k < Math.max(1, Math.floor(len * 0.01)); k++) {
      chars[Math.floor(Math.random() * chars.length)] = 'ACGT'[Math.floor(Math.random() * 4)];
    }
    return { ref: seqRef, patient: chars.join('') };
  }

  function addBenchRow(bodyId, len, time) {
    var row = document.createElement('tr');
    row.innerHTML = '<td>' + len + '</td><td>' + (len * len).toLocaleString() + '</td><td>' + time.toFixed(1) + '</td>';
    $(bodyId).appendChild(row);
  }

  function runBench(opts) {
    var lengths = [100, 200, 400, 800, 1600];
    var points = [];
    $(opts.tableId).style.display = 'table';
    $(opts.bodyId).innerHTML = '';
    $(opts.btnId).disabled = true;

    function step(idx) {
      if (idx >= lengths.length) {
        $(opts.statusId).textContent = 'benchmark complete.';
        $(opts.btnId).disabled = false;
        return;
      }
      var len = lengths[idx];
      $(opts.statusId).textContent = 'aligning length ' + len + '\u2026';
      setTimeout(function () {
        var pair = makePair(len);
        var t0 = performance.now();
        opts.fn(pair.ref, pair.patient, 2, -1, -2);
        var time = performance.now() - t0;
        points.push({ n: len, time: time });
        opts.draw(points);
        addBenchRow(opts.bodyId, len, time);
        step(idx + 1);
      }, 30);
    }
    step(0);
  }

  $('btnBench').addEventListener('click', function () {
    runBench({
      fn: G.smithWaterman,
      draw: G.drawPerfChart,
      tableId: 'perfTable',
      bodyId: 'perfTableBody',
      btnId: 'btnBench',
      statusId: 'benchStatus'
    });
  });

  if ($('btnBenchNw')) {
    $('btnBenchNw').addEventListener('click', function () {
      runBench({
        fn: G.needlemanWunsch,
        draw: G.drawNwPerfChart,
        tableId: 'nwPerfTable',
        bodyId: 'nwPerfTableBody',
        btnId: 'btnBenchNw',
        statusId: 'benchNwStatus'
      });
    });
  }

  /* ---------- init ---------- */
  showPage(pageFromPath());
  G.drawPerfChart([]);
  if (G.drawNwPerfChart) G.drawNwPerfChart([]);
  renderPresets();
  applyPreset(PRESETS[0]);
})(window.GeneScan = window.GeneScan || {});
