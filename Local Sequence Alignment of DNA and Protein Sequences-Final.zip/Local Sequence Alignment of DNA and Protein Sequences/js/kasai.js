/* Stage 1b — Kasai's LCP array construction: O(n) */
(function (G) {
  "use strict";

  function kasaiLCP(s, sa, rank) {
    var n = s.length;
    var lcp = new Array(n).fill(0);
    var h = 0;
    for (var i = 0; i < n; i++) {
      if (rank[i] > 0) {
        var j = sa[rank[i] - 1];
        while (i + h < n && j + h < n && s[i + h] === s[j + h]) h++;
        lcp[rank[i]] = h;
        if (h > 0) h--;
      } else {
        h = 0;
      }
    }
    return lcp;
  }

  G.kasaiLCP = kasaiLCP;
})(window.GeneScan = window.GeneScan || {});
