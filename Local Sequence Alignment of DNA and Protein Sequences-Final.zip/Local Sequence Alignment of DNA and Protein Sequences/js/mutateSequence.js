/* Random mutation (substitution / deletion / insertion) used by the batch screen,
   plus a random DNA generator used by the benchmark. */
(function (G) {
  "use strict";

  function mutateSequence(ref, alphabet) {
    var chars = ref.split('');
    var numMutations = 1 + Math.floor(Math.random() * 3);
    for (var k = 0; k < numMutations; k++) {
      var pos = Math.floor(Math.random() * chars.length);
      var roll = Math.random();
      if (roll < 0.7) {
        chars[pos] = alphabet[Math.floor(Math.random() * alphabet.length)];
      } else if (roll < 0.85 && chars.length > 10) {
        chars.splice(pos, 1); // deletion
      } else {
        chars.splice(pos, 0, alphabet[Math.floor(Math.random() * alphabet.length)]); // insertion
      }
    }
    return chars.join('');
  }

  function randomDNA(len) {
    var alphabet = 'ACGT';
    var out = '';
    for (var i = 0; i < len; i++) out += alphabet[Math.floor(Math.random() * 4)];
    return out;
  }

  G.mutateSequence = mutateSequence;
  G.randomDNA = randomDNA;
})(window.GeneScan = window.GeneScan || {});
