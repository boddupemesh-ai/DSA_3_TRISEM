# GeneScan — Local Sequence Alignment of DNA and Protein Sequences

Pure HTML + JavaScript. No Python, no server, no install — open `index.html` in a browser.

## Algorithms (one file each, in `js/`)

| File | Algorithm | Complexity |
|------|-----------|------------|
| `suffixArray.js` | Suffix array by prefix doubling | O(n log² n) |
| `kasai.js` | Kasai's LCP array | O(n) |
| `longestCommonSubstring.js` | Stage 1 — longest exact match (suffix array + LCP scan) | O(n log² n) |
| `smithWaterman.js` | Stage 2 — local alignment with traceback | O(n·m) |
| `edmondsKarp.js` | Module 4 — max-flow / min-cut (BFS augmenting paths) | O(VE²) |
| `detectType.js` | Input cleaning + DNA / PROTEIN / INVALID detection | O(n) |
| `mutateSequence.js` | Random mutation + random DNA (batch screen, benchmark) | O(n) |

## Other files

- `js/presets.js` — the preset pairs. Each DNA pair is exactly **2000 bases per sequence** (original motif + fixed seeded background, identical on every load).
- `js/render.js`, `js/charts.js`, `js/flowDemo.js` — drawing code only.
- `js/app.js` — button/textarea wiring.
- `index.html` — the same page and styling as before; text boxes now accept up to 2000 characters.

## Run

Double-click `index.html`.
